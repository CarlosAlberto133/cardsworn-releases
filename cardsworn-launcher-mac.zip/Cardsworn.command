#!/bin/bash
# ============================================================
#  Cardsworn — Launcher do macOS  (v1, out/2026)
#
#  Irmão do Launcher.ps1 do Windows: baixa a versão mais nova publicada no
#  GitHub Releases, instala, faz o login com o Google e abre o jogo.
#
#  ╔═══ POR QUE O MAC PRECISA DE UM LAUNCHER, E NÃO SÓ DE UM ZIP ═══╗
#
#  No Windows o launcher é uma comodidade: ele atualiza sozinho. No Mac ele é
#  NECESSÁRIO, porque a build é gerada numa máquina Windows e chega quebrada
#  de três jeitos que só se consertam no computador do jogador:
#
#    1) QUARENTENA — tudo que vem da internet ganha o atributo
#       com.apple.quarantine, e o Gatekeeper recusa app sem assinatura paga.
#    2) PERMISSÃO — o .zip feito no Windows não guarda o bit de execução, e o
#       binário dentro do .app chega sem permissão de rodar.
#    3) ASSINATURA — binário arm64 SÓ EXECUTA assinado, nem que seja ad-hoc. A
#       assinatura que a Unity gera no Windows não vale no Mac, e o sistema
#       mata o processo sem explicar.
#
#  Baixar o zip e dar duplo clique NÃO funciona. Este script conserta os três
#  (xattr, chmod, codesign) e por isso existe.
#
#  ⚠️ ELE NÃO SE AUTO-ATUALIZA — mesma regra do irmão do Windows. Quem
#  instalar tem uma cópia deste arquivo no Mac dele, então mudar o repositório
#  ou o NOME DO ASSET derruba a atualização de todos de uma vez, e só volta
#  quem baixar de novo pelo site. Pense duas vezes antes de mexer nas quatro
#  linhas de configuração abaixo.
# ============================================================

# ---------- CONFIGURAÇÃO ----------
REPO_OWNER="CarlosAlberto133"
REPO_NAME="cardsworn-releases"
ASSET_NAME="cardsworn-mac.app.zip"   # ⚠️ contrato: toda release precisa usar este nome
APP_NAME="Cardsworn.app"

SUPABASE_URL="https://zutdbgltjphsbakeeoda.supabase.co"
SUPABASE_KEY="sb_publishable_sIC5NDivItmQ_IuVOmWSdQ_LnyaSSOO"
AUTH_PORT=53682                      # a mesma porta do launcher do Windows
# ----------------------------------

set -o pipefail

# ---------- Caminhos ----------
# ~/Library/Application Support é o lugar canônico de dados de app no macOS.
#
# ⚠️ Tem de ser EXATAMENTE o que o jogo lê (MatchReporter.Dir). Se o launcher
# gravar a sessão num lugar e o jogo ler de outro, o login simplesmente não
# aparece — sem erro, sem log, sem nada: o jogador entra como anônimo e
# ninguém descobre o motivo.
ROOT="$HOME/Library/Application Support/Cardsworn"
GAME_DIR="$ROOT/game"
APP_PATH="$GAME_DIR/$APP_NAME"
VERSION_FILE="$ROOT/installed.txt"
SESSION_FILE="$ROOT/session.json"
LOG_FILE="$ROOT/launcher.log"
ZIP_TEMP="$ROOT/update.zip"

mkdir -p "$ROOT"

log() { printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE"; }
diga() { printf '%s\n' "$*"; log "$*"; }
erro() { printf '\n  ⚠️  %s\n' "$*"; log "ERRO: $*"; }

# Diálogo nativo em vez de "digite s/n": o .command abre no Terminal, e uma
# janela de verdade é menos assustadora para quem só quer jogar.
pergunta() {  # pergunta "texto" "botão-sim" "botão-não" -> 0 = sim
    osascript -e "button returned of (display dialog \"$1\" buttons {\"$3\", \"$2\"} \
        default button \"$2\" with title \"Cardsworn\")" 2>/dev/null | grep -q "^$2$"
}

cabecalho() {
    clear
    cat <<'ARTE'

   ╔═══════════════════════════════════════╗
   ║            C A R D S W O R N          ║
   ║            launcher · macOS           ║
   ╚═══════════════════════════════════════╝

ARTE
}

# ═══════════════════════════════════════════════════════════
#  1. QUAL É A VERSÃO MAIS NOVA
# ═══════════════════════════════════════════════════════════
#
# Pelo REDIRECT de /releases/latest, e não pela api.github.com — a API tem
# limite de 60 requisições por hora POR IP, e dois amigos no mesmo provedor
# (ou atrás do mesmo CGNAT) estouram isso e recebem um 403 que parece "sem
# internet". O redirect não tem esse limite. Mesma lição que o launcher do
# Windows aprendeu na v3.
versao_mais_nova() {
    local url
    url=$(curl -sIL -o /dev/null -w '%{url_effective}' \
          "https://github.com/$REPO_OWNER/$REPO_NAME/releases/latest" 2>/dev/null)
    [[ "$url" == *"/tag/"* ]] || return 1
    printf '%s' "${url##*/tag/}"
}

# ═══════════════════════════════════════════════════════════
#  2. BAIXAR E INSTALAR
# ═══════════════════════════════════════════════════════════
instalar() {
    local tag="$1"
    local url="https://github.com/$REPO_OWNER/$REPO_NAME/releases/download/$tag/$ASSET_NAME"

    diga "Baixando a versão $tag..."
    log "URL: $url"
    if ! curl -L --fail --progress-bar -o "$ZIP_TEMP" "$url"; then
        erro "O download falhou. Confira a conexão e tente de novo."
        return 1
    fi

    diga "Instalando..."
    rm -rf "$GAME_DIR"
    mkdir -p "$GAME_DIR"

    # ditto e não unzip: é a ferramenta da Apple para pacotes, e preserva a
    # estrutura do .app (recursos bifurcados, links) que o unzip genérico
    # às vezes achata.
    if ! ditto -x -k "$ZIP_TEMP" "$GAME_DIR" 2>>"$LOG_FILE"; then
        erro "Não consegui descompactar o arquivo baixado."
        rm -f "$ZIP_TEMP"
        return 1
    fi
    rm -f "$ZIP_TEMP"

    # O zip pode ter vindo com uma pasta extra em volta: acha o .app onde ele
    # estiver em vez de exigir um formato exato de quem empacotou.
    local achado
    achado=$(find "$GAME_DIR" -maxdepth 3 -name "*.app" -type d | head -n 1)
    if [[ -z "$achado" ]]; then
        erro "O pacote baixado não tem nenhum aplicativo dentro."
        return 1
    fi
    if [[ "$achado" != "$APP_PATH" ]]; then
        mv "$achado" "$APP_PATH" 2>/dev/null || APP_PATH="$achado"
    fi

    consertar "$APP_PATH" || return 1

    printf '%s' "$tag" > "$VERSION_FILE"
    diga "Versão $tag instalada."
}

# ═══════════════════════════════════════════════════════════
#  3. O CONSERTO (o motivo deste launcher existir)
# ═══════════════════════════════════════════════════════════
consertar() {
    local app="$1"
    diga "Preparando o aplicativo para o macOS..."

    # (a) tira a quarentena do download. Sem isto o Gatekeeper recusa antes
    #     mesmo de olhar a assinatura.
    xattr -cr "$app" 2>>"$LOG_FILE"

    # (b) devolve o bit de execução que o zip do Windows não carrega.
    chmod -R +x "$app/Contents/MacOS" 2>>"$LOG_FILE"
    find "$app/Contents" -name "*.dylib" -exec chmod +x {} \; 2>>"$LOG_FILE"

    # (c) reassina ad-hoc NO MAC DO JOGADOR.
    #
    #     ⚠️ Esta é a parte que não dá para pular num Mac com Apple Silicon:
    #     o kernel recusa binário arm64 sem assinatura válida. A assinatura
    #     que a Unity escreve rodando no Windows não é válida aqui, e o
    #     sintoma é o app "abrir e fechar na hora", sem mensagem nenhuma.
    if ! codesign --force --deep --sign - "$app" 2>>"$LOG_FILE"; then
        erro "Não consegui assinar o aplicativo. Veja $LOG_FILE"
        return 1
    fi
    log "Conserto aplicado (xattr + chmod + codesign ad-hoc)"
}

# ═══════════════════════════════════════════════════════════
#  4. LOGIN COM O GOOGLE (PKCE, igual ao do Windows)
# ═══════════════════════════════════════════════════════════
#
# PKCE justamente para NÃO existir segredo embutido neste arquivo: o launcher
# é distribuído em texto puro, e qualquer um pode lê-lo. O que vai aqui é só a
# chave publicável do Supabase, que é pública por definição.

# Lê um campo de um JSON sem depender de jq (que o macOS não tem) nem de
# python3 (que a Apple tirou do sistema base). O plutil está em /usr/bin desde
# sempre e entende JSON.
campo() {  # campo "<json>" "chave.aninhada"
    local v
    v=$(printf '%s' "$1" | plutil -extract "$2" raw -o - -- - 2>/dev/null)
    if [[ -n "$v" && "$v" != "<stdin>"* ]]; then printf '%s' "$v"; return 0; fi

    # Reserva: o plutil é da Apple e está em /usr/bin desde sempre, mas o
    # -extract de JSON pela entrada padrão é recente o bastante para eu não
    # querer apostar o login nele. Para um campo simples, o sed resolve — e
    # pega só a última parte da chave, que basta porque os nomes não se
    # repetem nesta resposta.
    printf '%s' "$1" | sed -n "s/.*\"${2##*.}\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p" | head -n 1
}

sessao_atual() {
    [[ -f "$SESSION_FILE" ]] || return 1
    campo "$(cat "$SESSION_FILE")" "email"
}

login_google() {
    # verifier aleatório + challenge = base64url(sha256(verifier))
    local verifier challenge
    verifier=$(LC_ALL=C tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 64)
    challenge=$(printf '%s' "$verifier" | openssl dgst -binary -sha256 \
                | openssl base64 | tr '+/' '-_' | tr -d '=')

    local redirect="http%3A%2F%2Flocalhost%3A$AUTH_PORT%2Fcallback"
    local url="$SUPABASE_URL/auth/v1/authorize?provider=google&redirect_to=$redirect"
    url="$url&code_challenge=$challenge&code_challenge_method=s256"

    if lsof -nP -iTCP:"$AUTH_PORT" -sTCP:LISTEN >/dev/null 2>&1; then
        erro "A porta $AUTH_PORT está ocupada. Feche o que estiver usando e tente de novo."
        return 1
    fi

    diga "Abrindo o navegador para o login..."
    open "$url"

    # Servidor de uma requisição só, para pegar o ?code= do retorno.
    #
    # ⚠️ nc e não um servidor de verdade: o macOS não traz runtime nenhum
    # garantido (sem python3, sem node), e o netcat da BSD está em toda
    # instalação. Ele atende UMA conexão e sai, que é exatamente a vida útil
    # que este servidor precisa ter.
    local resposta pedido code alvo ncpid i
    resposta=$'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\n\r\n<html><body style="font-family:-apple-system;background:#15100a;color:#f3e8d3;text-align:center;padding-top:80px"><h2>Login concluído!</h2><p>Pode fechar esta aba e voltar ao launcher.</p></body></html>'

    # ⚠️ O nc em SEGUNDO PLANO com um vigia, e não em primeiro plano.
    #
    # `nc -l` fica esperando para sempre. Se o jogador fechar a aba do
    # navegador sem concluir o login — ou simplesmente desistir — o launcher
    # ficaria pendurado num Terminal que não responde, e a única saída seria
    # matar a janela. Com o vigia, 3 minutos e ele volta sozinho.
    alvo=$(mktemp "${TMPDIR:-/tmp}/cardsworn-auth.XXXXXX")
    printf '%s' "$resposta" | nc -l "$AUTH_PORT" > "$alvo" 2>/dev/null &
    ncpid=$!

    diga "Aguardando o login no navegador (3 minutos)..."
    for ((i = 0; i < 180; i++)); do
        kill -0 "$ncpid" 2>/dev/null || break
        sleep 1
    done
    kill "$ncpid" 2>/dev/null
    wait "$ncpid" 2>/dev/null

    pedido=$(head -n 1 "$alvo" 2>/dev/null)
    rm -f "$alvo"

    code=$(printf '%s' "$pedido" | sed -n 's/.*[?&]code=\([^& ]*\).*/\1/p')
    if [[ -z "$code" ]]; then
        erro "O login não foi concluído (nenhum código recebido)."
        return 1
    fi

    diga "Validando..."
    local tok
    tok=$(curl -s -X POST "$SUPABASE_URL/auth/v1/token?grant_type=pkce" \
          -H "apikey: $SUPABASE_KEY" -H 'Content-Type: application/json' \
          -d "{\"auth_code\":\"$code\",\"code_verifier\":\"$verifier\"}")

    local access refresh uid email nome expira agora
    access=$(campo "$tok" "access_token")
    refresh=$(campo "$tok" "refresh_token")
    uid=$(campo "$tok" "user.id")
    email=$(campo "$tok" "user.email")
    nome=$(campo "$tok" "user.user_metadata.full_name")
    [[ -z "$nome" ]] && nome=$(campo "$tok" "user.user_metadata.name")
    expira=$(campo "$tok" "expires_in")
    [[ -z "$expira" ]] && expira=3600

    if [[ -z "$access" || -z "$uid" ]]; then
        erro "O servidor não devolveu a sessão. Tente de novo."
        log "Resposta do token: $tok"
        return 1
    fi

    agora=$(date +%s)
    # ⚠️ O formato é o que o jogo lê (MatchReporter.SessionData): mesmos nomes
    # de campo, expires_at em segundos desde 1970. Mudar um nome aqui faz o
    # jogo ignorar a sessão em silêncio.
    cat > "$SESSION_FILE" <<JSON
{"access_token":"$access","refresh_token":"$refresh","user_id":"$uid","email":"$email","name":"$nome","expires_at":$((agora + expira))}
JSON
    diga "Login concluído: $email"

    # Perfil no banco. Não-fatal: falhar aqui não pode impedir ninguém de jogar.
    curl -s -X POST "$SUPABASE_URL/rest/v1/profiles" \
         -H "apikey: $SUPABASE_KEY" -H "Authorization: Bearer $access" \
         -H 'Content-Type: application/json' -H 'Prefer: resolution=merge-duplicates' \
         -d "{\"id\":\"$uid\",\"email\":\"$email\",\"full_name\":\"$nome\",\"last_login\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}" \
         >/dev/null 2>>"$LOG_FILE" || log "Perfil: upsert falhou (não-fatal)"
}

# ═══════════════════════════════════════════════════════════
#  5. O FLUXO
# ═══════════════════════════════════════════════════════════
cabecalho
log "---- launcher iniciado ----"

instalada=""
[[ -f "$VERSION_FILE" ]] && instalada=$(cat "$VERSION_FILE")

diga "Procurando atualizações..."
nova=$(versao_mais_nova)

if [[ -z "$nova" ]]; then
    if [[ -d "$APP_PATH" ]]; then
        diga "Sem conexão com o GitHub — abrindo a versão instalada ($instalada)."
    else
        erro "Sem conexão com o GitHub e nada instalado ainda. Tente mais tarde."
        read -r -p "  Pressione Enter para fechar."
        exit 1
    fi
elif [[ "$nova" != "$instalada" || ! -d "$APP_PATH" ]]; then
    if [[ -n "$instalada" ]]; then
        diga "Versão nova disponível: $instalada → $nova"
    fi
    instalar "$nova" || { read -r -p "  Pressione Enter para fechar."; exit 1; }
else
    diga "Você já está na versão mais nova ($instalada)."
fi

# ---------- login ----------
conta=$(sessao_atual)
if [[ -n "$conta" ]]; then
    diga "Conectado como $conta"
else
    echo
    if pergunta "Entrar com a sua conta Google?\n\nSem login o jogo funciona igual — o login só guarda as suas partidas e estatísticas na sua conta." "Entrar" "Agora não"; then
        login_google || diga "Seguindo sem login."
    else
        diga "Seguindo sem login."
    fi
fi

# ---------- abrir ----------
echo
if [[ ! -d "$APP_PATH" ]]; then
    erro "Não achei o jogo instalado. Rode o launcher de novo."
    read -r -p "  Pressione Enter para fechar."
    exit 1
fi

diga "Abrindo o Cardsworn..."
if ! open "$APP_PATH" 2>>"$LOG_FILE"; then
    erro "O macOS recusou abrir o aplicativo."
    echo
    echo "  Vá em Ajustes do Sistema → Privacidade e Segurança,"
    echo "  role até o fim e clique em \"Abrir Assim Mesmo\"."
    echo
    read -r -p "  Pressione Enter para fechar."
    exit 1
fi

sleep 2
exit 0
